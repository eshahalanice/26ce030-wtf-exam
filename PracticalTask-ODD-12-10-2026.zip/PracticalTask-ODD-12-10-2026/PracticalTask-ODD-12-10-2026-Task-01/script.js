function calculateFee() {
    const baseFee = document.getElementById("baseFee").value;
    const labFee = Number(document.getElementById("labFee").value);
    const semesters = Number(document.getElementById("semesters").value);
    const scholarship = document.getElementById("scholarship").value;
    const subtotal = baseFee + labFee;
    const rate = getRate(scholarship);
    const discount = calculateDiscount(subtotal, rate);
    const adminCharge = subtotal * 0.50;
    const payable = calculateTotal(subtotal, discount, adminCharge);
    document.getElementById("result").textContent = "Subtotal: ₹" + subtotal + " | Discount: ₹" + discount + " | Administration: ₹" + adminCharge + " | Payable: ₹" + payable;
    document.getElementById("breakdown").textContent = buildBreakdown(payable, semesters);
}

function calculateDiscount(amount, percentage) {
    // TODO M6: Replace the return value with the formula for a percentage discount.
    return 0;
}

function getRate(type) {
    // TODO D1: Use if / else if / else. Merit=20, Sports=10, None=0.
    return 0;
}

function calculateTotal(subtotal, discount, adminCharge) {
    // TODO D2: Return the payable amount after discount and administration charge.
    return subtotal;
}

function buildBreakdown(payable, count) {
    // TODO D3: Use a for loop from semester 1 to count. Show cumulative fee (payable * semester).
    return "Complete the semester-wise summary.";
}
